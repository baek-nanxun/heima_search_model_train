#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.5: focused error signals.
For each task compute: invalid (out-of-vocab/structural), entity->label conflicts,
taxonomy ambiguities. Emit focused to_fix lists for LLM agents.
"""
import json, re, os
from collections import defaultdict

BASE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/code/data/gemini_labeled_v2/tasks_fixed"
JOB_CATE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/job_cate.json"
FOC_DIR = os.path.join(BASE, "_clean", "focus")
os.makedirs(FOC_DIR, exist_ok=True)

def tolerant_json(s):
    if not isinstance(s, str): return None
    s = s.strip()
    try: return json.loads(s)
    except Exception: pass
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", s, re.S)
    if m:
        try: return json.loads(m.group(1))
        except Exception: pass
    m = re.search(r"\{.*\}", s, re.S)
    if m:
        try: return json.loads(m.group(0))
        except Exception: pass
    return None

def assistant_content(d):
    if d.get("output"): return d["output"]
    for m in d.get("messages", []):
        if m.get("role") == "assistant": return m.get("content", "")
    return None

def extract_candidates(instr):
    m = re.search(r"候选分类体系（必须严格遵守）：(\[.*?\])", instr, re.S)
    if not m: return None
    try: return json.loads(m.group(1))
    except Exception: return None

with open(JOB_CATE, encoding="utf-8") as f:
    jc = json.load(f)
L3_PARENTS = {}
CHILDREN_OF = {}
PATH_SET = set()
for l1, l2map in jc.items():
    for l2, l3list in l2map.items():
        PATH_SET.add((l1, l2))
        CHILDREN_OF[(l1, l2)] = set(l3list)
        for l3 in l3list:
            L3_PARENTS.setdefault(l3, set()).add((l2, l1))

TASKS = ["benefit_classification","work_time_classification","workplace_classification",
         "settlement_classification","work_type_classification",
         "taxonomy_leaf_to_parent","taxonomy_level2_to_children"]

CAND = {}
WP_L1 = set(); WP_SPLITS = set()
for t in TASKS:
    p = os.path.join(BASE, t, "train.jsonl")
    with open(p, encoding="utf-8") as f:
        first = json.loads(f.readline())
    instr = first.get("instruction", "")
    c = extract_candidates(instr)
    if t == "workplace_classification":
        WP_L1 = set(x.split("-",1)[0] for x in c)
        WP_SPLITS = set(tuple(x.split("-",1)) for x in c)
    CAND[t] = c

def load_records(t):
    p = os.path.join(BASE, t, "train.jsonl")
    recs = []
    with open(p, encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            recs.append(json.loads(line))
    return recs

summary = {}
for t in TASKS:
    recs = load_records(t)
    invalid = []          # (sample_id, entity, predicted_key, detail)
    conflicts = defaultdict(lambda: defaultdict(int))  # entity -> predicted_key -> count
    conflict_samples = {}  # entity -> sample_id
    for d in recs:
        sid = d.get("sample_id")
        parsed = tolerant_json(assistant_content(d))
        if t in ("benefit_classification","settlement_classification","work_type_classification"):
            f = "standardBenefit" if t=="benefit_classification" else "category"
            val = parsed.get(f) if parsed else None
            ent = (parsed.get("entity","") if parsed else "")
            cand = CAND[t]
            valid = isinstance(val,str) and val in cand
            key = val if isinstance(val,str) else "__NONE__"
            if not valid:
                invalid.append((sid, ent, key, {"field":f}))
            conflicts[ent][key]+=1
            if ent not in conflict_samples: conflict_samples[ent]=sid
        elif t=="work_time_classification":
            fc = parsed.get("fullCategory") if parsed else None
            l1 = parsed.get("level1") if parsed else None
            l2 = parsed.get("level2") if parsed else None
            ent = (parsed.get("entity","") if parsed else "")
            cand = CAND[t]
            # valid: fc in cand AND (fc=="其他" => l1==l2=="" ) OR fc==l1+"-"+l2
            if fc=="其他":
                valid = (l1=="" and l2=="")
            else:
                valid = isinstance(fc,str) and fc in cand and (l1==fc.split("-",1)[0] and l2==fc.split("-",1)[1] if "-" in fc else False)
            key = fc if isinstance(fc,str) else "__NONE__"
            if not valid:
                invalid.append((sid, ent, key, {"fc":fc,"l1":l1,"l2":l2}))
            conflicts[ent][key]+=1
            if ent not in conflict_samples: conflict_samples[ent]=sid
        elif t=="workplace_classification":
            l1 = parsed.get("level1") if parsed else None
            l2 = parsed.get("level2") if parsed else None
            rawwp = (parsed.get("rawWorkPlace","") if parsed else "")
            key = f"{l1}||{l2}"
            valid = isinstance(l1,str) and l1 in WP_L1 and (
                (isinstance(l2,str) and (l1,l2) in WP_SPLITS) or (isinstance(l2,str) and l2==rawwp))
            if not valid:
                invalid.append((sid, rawwp, key, {"l1":l1,"l2":l2,"raw":rawwp}))
            conflicts[rawwp][key]+=1
            if rawwp not in conflict_samples: conflict_samples[rawwp]=sid
        elif t=="taxonomy_leaf_to_parent":
            l3 = parsed.get("level3") if parsed else None
            l2 = parsed.get("level2") if parsed else None
            l1 = parsed.get("level1") if parsed else None
            key = f"{l3}||{l2}||{l1}"
            valid = isinstance(l3,str) and l3 in L3_PARENTS and (isinstance(l2,str) and isinstance(l1,str) and (l2,l1) in L3_PARENTS[l3])
            if not valid:
                invalid.append((sid, l3, key, {"l3":l3,"l2":l2,"l1":l1}))
            conflicts[l3][key]+=1
            if l3 not in conflict_samples: conflict_samples[l3]=sid
        elif t=="taxonomy_level2_to_children":
            l1 = parsed.get("level1") if parsed else None
            l2 = parsed.get("level2") if parsed else None
            kids = [k for k in (parsed.get("level3Children",[]) or []) if isinstance(k,str)]
            key = f"{l1}||{l2}"
            canon = CHILDREN_OF.get((l1,l2))
            valid = canon is not None and set(kids)==canon
            if not valid:
                invalid.append((sid, f"{l1}/{l2}", key, {"l1":l1,"l2":l2,"n_kids":len(kids),"canon_n":len(canon) if canon else -1}))
            # children set as the "label"
            conflicts[key][tuple(sorted(kids))]+=1
            if key not in conflict_samples: conflict_samples[key]=sid
    # conflicts: entity with >1 distinct predicted label
    conflict_entities = {e:dict(ks) for e,ks in conflicts.items() if len(ks)>1}
    # for taxonomy_leaf, also flag ambiguous leaves (multiple valid parents in tree) that appear
    out = {
        "task": t,
        "total": len(recs),
        "n_invalid": len(invalid),
        "invalid": invalid,
        "n_conflict_entities": len(conflict_entities),
        "conflict_entities": conflict_entities,
        "conflict_samples": conflict_samples,
    }
    with open(os.path.join(FOC_DIR, t+".json"),"w",encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    summary[t] = {"total":len(recs),"invalid":len(invalid),"conflict_entities":len(conflict_entities)}
    print(f"[{t}] total={len(recs)} invalid={len(invalid)} conflict_entities={len(conflict_entities)}")

print("\nSUMMARY:", json.dumps(summary, ensure_ascii=False))
