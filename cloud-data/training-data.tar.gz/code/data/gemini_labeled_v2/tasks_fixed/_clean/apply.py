#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 3: Apply LLM decisions to rewrite train.cleaned.jsonl per task,
diff job_name_classification, build Excel of all label changes.
"""
import json, os, re
from openpyxl import Workbook
from collections import OrderedDict

BASE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/code/data/gemini_labeled_v2/tasks_fixed"
DEC = os.path.join(BASE, "_clean", "decisions")
JOB_CATE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/job_cate.json"

# ---------- Helpers ----------
def tolerant_json(s):
    if not isinstance(s, str): return None
    s=s.strip()
    try: return json.loads(s)
    except Exception: pass
    m=re.search(r"```(?:json)?\s*(\{.*?\})\s*```", s, re.S)
    if m:
        try: return json.loads(m.group(1))
        except Exception: pass
    m=re.search(r"\{.*\}", s, re.S)
    if m:
        try: return json.loads(m.group(0))
        except Exception: pass
    return None

def assistant_content(d):
    if d.get("output"): return d["output"]
    for m in d.get("messages", []):
        if m.get("role")=="assistant": return m.get("content","")
    return None

# ---------- Load job_cate (for taxonomy tasks) ----------
with open(JOB_CATE, encoding="utf-8") as f: jc=json.load(f)
L3_PARENTS={}; CHILDREN_OF={}; CAND_WP_L1=set(); CAND_WP_SPLITS=set()
# Load workplace candidates from context
ctx_wp=json.load(open(os.path.join(BASE,"_clean","context","workplace_classification.json")))
CAND_WP_L1=set(ctx_wp["wp_l1"])
CAND_WP_SPLITS=set(tuple(x) for x in ctx_wp["wp_splits"])
for l1,l2map in jc.items():
    for l2,l3list in l2map.items():
        CHILDREN_OF[(l1,l2)]=l3list
        for l3 in l3list:
            L3_PARENTS.setdefault(l3,set()).add((l2,l1))

# ---------- Rewrite output helper ----------
def rewrite_output(out_str, task, new_key, entity_override=None):
    """Rewrite the output JSON to replace label(s) with new_key.
    Returns updated output string, or original if cannot parse."""
    parsed = tolerant_json(out_str)
    if parsed is None:
        return out_str  # can't parse, keep original
    if task == "benefit_classification":
        parsed["standardBenefit"] = new_key
    elif task == "settlement_classification":
        parsed["category"] = new_key
    elif task == "work_type_classification":
        parsed["category"] = new_key
    elif task == "work_time_classification":
        parsed["fullCategory"] = new_key
        if new_key == "其他":
            parsed["level1"] = ""
            parsed["level2"] = ""
        else:
            parts = new_key.split("-", 1)
            parsed["level1"] = parts[0]
            parsed["level2"] = parts[1] if len(parts) > 1 else ""
    elif task == "workplace_classification":
        parts = new_key.split("||", 1)
        parsed["level1"] = parts[0]
        parsed["level2"] = parts[1] if len(parts) > 1 else ""
    elif task == "taxonomy_leaf_to_parent":
        parts = new_key.split("||", 2)
        parsed["level3"] = parts[0]
        parsed["level2"] = parts[1] if len(parts) > 1 else ""
        parsed["level1"] = parts[2] if len(parts) > 2 else ""
    elif task == "taxonomy_level2_to_children":
        parts = new_key.split("||", 2)
        parsed["level1"] = parts[0]
        parsed["level2"] = parts[1] if len(parts) > 1 else ""
        if len(parts) > 2:
            parsed["level3Children"] = [c for c in parts[2].split(",") if c]
    return json.dumps(parsed, ensure_ascii=False)

# ---------- Apply decisions per task ----------
TASKS = ["benefit_classification","work_time_classification","workplace_classification",
         "settlement_classification","work_type_classification",
         "taxonomy_leaf_to_parent","taxonomy_level2_to_children"]

all_changes = []  # list of dict for Excel

for t in TASKS:
    orig_path = os.path.join(BASE, t, "train.jsonl")
    cleaned_path = os.path.join(BASE, t, "train.cleaned.jsonl")
    
    # Load all decisions for this task
    decisions = {}
    for fname in os.listdir(DEC):
        if fname.startswith(t+"__") and fname.endswith(".jsonl"):
            fp = os.path.join(DEC, fname)
            if os.path.getsize(fp) == 0:
                continue
            with open(fp, encoding="utf-8") as f:
                for line in f:
                    line=line.strip()
                    if not line: continue
                    d=json.loads(line)
                    if d.get("changed"):
                        decisions[int(d["lineno"])] = d
    
    n_changed = 0
    n_skipped_invalid = 0
    n_total = 0
    
    with open(orig_path, encoding="utf-8") as fin, \
         open(cleaned_path, "w", encoding="utf-8") as fout:
        for lineno, line in enumerate(fin):
            line = line.strip()
            if not line: continue
            n_total += 1
            if lineno in decisions:
                dec = decisions[lineno]
                new_key = dec["new_key"]
                # Validate new_key
                valid = True
                if t in ("benefit_classification",):
                    cand = json.load(open(os.path.join(BASE,"_clean","context",t+".json")))["candidates"]
                    if new_key not in cand: valid = False
                elif t in ("settlement_classification","work_type_classification"):
                    cand = json.load(open(os.path.join(BASE,"_clean","context",t+".json")))["candidates"]
                    if new_key not in cand: valid = False
                elif t == "work_time_classification":
                    cand = json.load(open(os.path.join(BASE,"_clean","context",t+".json")))["candidates"]
                    if not (new_key in cand):
                        valid = False
                elif t == "workplace_classification":
                    parts = new_key.split("||", 1)
                    l1, l2 = parts[0], parts[1] if len(parts)>1 else ""
                    if l1 not in CAND_WP_L1:
                        valid = False
                    if not ((l1,l2) in CAND_WP_SPLITS or l2 == "其他"):
                        # Allow raw entity as L2
                        pass
                
                if not valid:
                    n_skipped_invalid += 1
                    fout.write(line + "\n")
                    continue
                
                d = json.loads(line)
                orig_out = assistant_content(d)
                new_out = rewrite_output(orig_out, t, new_key)
                d["output"] = new_out
                # Also fix messages[-1].content
                msgs = d.get("messages", [])
                for i in range(len(msgs)-1, -1, -1):
                    if msgs[i].get("role") == "assistant":
                        msgs[i]["content"] = new_out
                        break
                fout.write(json.dumps(d, ensure_ascii=False) + "\n")
                n_changed += 1
                
                # Record for Excel
                all_changes.append({
                    "task": t,
                    "sample_id": dec.get("sample_id", ""),
                    "lineno": lineno,
                    "entity": new_out[:60],  # wont show full but ok
                    "original_label": dec.get("original_key", ""),
                    "new_label": new_key,
                    "reason": dec.get("reason", "")
                })
            else:
                fout.write(line + "\n")
    
    print(f"[{t}] total={n_total} changed={n_changed} skipped_invalid={n_skipped_invalid}")

# ---------- job_name_classification: diff original vs existing cleaned ----------
print("\n--- job_name_classification diff ---")
job_orig = os.path.join(BASE, "job_name_classification", "train.jsonl")
job_cleaned = os.path.join(BASE, "job_name_classification", "train.cleaned.jsonl")

# Check if cleaned file exists
if os.path.exists(job_cleaned):
    changes_jn = 0
    with open(job_orig, encoding="utf-8") as fo, \
         open(job_cleaned, encoding="utf-8") as fc:
        for lineno, (lo, lc) in enumerate(zip(fo, fc)):
            lo=lo.strip(); lc=lc.strip()
            if not lo and not lc: continue
            if lo != lc:
                do=json.loads(lo)
                dc=json.loads(lc)
                orig_out = assistant_content(do) or ""
                clean_out = assistant_content(dc) or ""
                if orig_out != clean_out:
                    changes_jn += 1
                    all_changes.append({
                        "task": "job_name_classification",
                        "sample_id": do.get("sample_id", lineno),
                        "lineno": lineno,
                        "entity": do.get("input","")[:100],
                        "original_label": orig_out[:100],
                        "new_label": clean_out[:100],
                        "reason": "原清洗(歧义/路径修正)"
                    })
        print(f"[job_name_classification] diff changes: {changes_jn}")
else:
    print("[job_name_classification] train.cleaned.jsonl not found, skipping diff")

print(f"\nTotal label changes across all tasks: {len(all_changes)}")

# ---------- Build Excel ----------
wb = Workbook()
ws_summary = wb.active
ws_summary.title = "汇总"

# Summary
task_counts = {}
for ch in all_changes:
    task_counts[ch["task"]] = task_counts.get(ch["task"], 0) + 1

ws_summary["A1"] = "任务"
ws_summary["B1"] = "变更记录数"
ws_summary["C1"] = "变更类型说明"
for i, (t, cnt) in enumerate(sorted(task_counts.items()), 2):
    ws_summary[f"A{i}"] = t
    ws_summary[f"B{i}"] = cnt
    if t == "workplace_classification":
        ws_summary[f"C{i}"] = "Level2'其他'→原始场所名"
    elif t == "benefit_classification":
        ws_summary[f"C{i}"] = "LLM语义修正"
    else:
        ws_summary[f"C{i}"] = "LLM语义修正/数据清洗"

ws_detail = wb.create_sheet("变更明细")
ws_detail["A1"] = "任务"
ws_detail["B1"] = "行号"
ws_detail["C1"] = "Sample ID"
ws_detail["D1"] = "原始label"
ws_detail["E1"] = "新label"
ws_detail["F1"] = "变更原因"
for i, ch in enumerate(all_changes, 2):
    ws_detail[f"A{i}"] = ch["task"]
    ws_detail[f"B{i}"] = ch.get("lineno", "")
    ws_detail[f"C{i}"] = ch.get("sample_id", "")
    ws_detail[f"D{i}"] = ch.get("original_label", "")
    ws_detail[f"E{i}"] = ch.get("new_label", "")
    ws_detail[f"F{i}"] = ch.get("reason", "")

xlsx_path = os.path.join(BASE, "label_changes.xlsx")
wb.save(xlsx_path)
print(f"\nExcel saved to: {xlsx_path}")
