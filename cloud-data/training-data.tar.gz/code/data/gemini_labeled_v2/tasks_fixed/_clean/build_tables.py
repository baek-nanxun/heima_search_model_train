#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1.5b: build compact judgment tables + per-task context for LLM agents."""
import json, re, os
BASE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/code/data/gemini_labeled_v2/tasks_fixed"
JOB_CATE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/job_cate.json"
TBL_DIR = os.path.join(BASE, "_clean", "tables")
CTX_DIR = os.path.join(BASE, "_clean", "context")
os.makedirs(TBL_DIR, exist_ok=True); os.makedirs(CTX_DIR, exist_ok=True)

def tolerant_json(s):
    if not isinstance(s, str): return None
    s=s.strip()
    try: return json.loads(s)
    except Exception: pass
    m=re.search(r"```(?:json)?\s*(\{.*?\})\s*```", s, re.S)
    if m:
        try: return json.loads(m.group(1))
        except Exception: pass
    m=re.search(r"\{.*\}", s, re.S)
    if m:
        try: return json.loads(m.group(0))
        except Exception: pass
    return None
def assistant_content(d):
    if d.get("output"): return d["output"]
    for m in d.get("messages", []):
        if m.get("role")=="assistant": return m.get("content","")
    return None
def extract_candidates(instr):
    m=re.search(r"候选分类体系（必须严格遵守）：(\[.*?\])", instr, re.S)
    if not m: return None
    try: return json.loads(m.group(1))
    except Exception: return None

with open(JOB_CATE, encoding="utf-8") as f: jc=json.load(f)
L3_PARENTS={}; CHILDREN_OF={}
for l1,l2map in jc.items():
    for l2,l3list in l2map.items():
        CHILDREN_OF[(l1,l2)]=list(l3list)
        for l3 in l3list: L3_PARENTS.setdefault(l3,[]).append([l2,l1])

TASKS=["benefit_classification","work_time_classification","workplace_classification",
       "settlement_classification","work_type_classification",
       "taxonomy_leaf_to_parent","taxonomy_level2_to_children"]
CAND={}; WP_L1=set(); WP_SPLITS=set(); INSTR={}
for t in TASKS:
    p=os.path.join(BASE,t,"train.jsonl")
    with open(p,encoding="utf-8") as f:
        first=json.loads(f.readline())
    INSTR[t]=first.get("instruction","")
    c=extract_candidates(INSTR[t])
    if t=="workplace_classification":
        WP_L1=set(x.split("-",1)[0] for x in c)
        WP_SPLITS=set(tuple(x.split("-",1)) for x in c)
    CAND[t]=c

FORMAT_SPEC = {
 "benefit_classification":"new_key = 标准福利字符串(来自候选集), 例如 '交通补贴/班车'",
 "settlement_classification":"new_key = 结算方式字符串(来自候选集), 例如 '月结'",
 "work_type_classification":"new_key = 用工类型字符串(来自候选集), 例如 '兼职工'",
 "work_time_classification":"new_key = fullCategory字符串(来自候选集), 例如 '白班制-长白班' 或 '其他'",
 "workplace_classification":"new_key = 'L1||L2' 其中L1属于候选一级, L2是该一级下候选二级(来自候选集拆分) 或 原始场所名; 例如 '餐饮店||中餐厅'",
 "taxonomy_leaf_to_parent":"new_key = 'L3||L2||L1' 必须来自job_cate.json中该L3的合法父节点; 例如 'Java||后端开发||互联网/AI'",
 "taxonomy_level2_to_children":"new_key = 'L1||L2||child1,child2,...' 其中children为该(L1,L2)在job_cate.json中的全部三级职位(不遗漏不新增)",
}

for t in TASKS:
    p=os.path.join(BASE,t,"train.jsonl")
    tbl=[]
    with open(p,encoding="utf-8") as f:
        for lineno,line in enumerate(f):
            line=line.strip()
            if not line: continue
            d=json.loads(line)
            sid=d.get("sample_id")
            parsed=tolerant_json(assistant_content(d))
            inp=d.get("input","")
            snippet=inp[:200]
            rec={"lineno":lineno,"sample_id":sid,"snippet":snippet}
            if t in ("benefit_classification","settlement_classification","work_type_classification"):
                fld="standardBenefit" if t=="benefit_classification" else "category"
                rec["entity"]=parsed.get("entity","") if parsed else ""
                rec["predicted_key"]=parsed.get(fld,"") if parsed else ""
            elif t=="work_time_classification":
                rec["entity"]=parsed.get("entity","") if parsed else ""
                rec["predicted_key"]=parsed.get("fullCategory","") if parsed else ""
            elif t=="workplace_classification":
                rec["entity"]=parsed.get("rawWorkPlace","") if parsed else ""
                rec["predicted_key"]=f"{parsed.get('level1','')}||{parsed.get('level2','')}" if parsed else ""
            elif t=="taxonomy_leaf_to_parent":
                l3=parsed.get("level3","") if parsed else ""
                rec["entity"]=l3
                rec["predicted_key"]=f"{l3}||{parsed.get('level2','')}||{parsed.get('level1','')}" if parsed else ""
                rec["valid_parents"]=L3_PARENTS.get(l3,[])
            elif t=="taxonomy_level2_to_children":
                l1=parsed.get("level1","") if parsed else ""
                l2=parsed.get("level2","") if parsed else ""
                rec["entity"]=f"{l1}/{l2}"
                rec["predicted_key"]=f"{l1}||{l2}"
                rec["canonical_children"]=CHILDREN_OF.get((l1,l2),[])
            tbl.append(rec)
    with open(os.path.join(TBL_DIR,t+".jsonl"),"w",encoding="utf-8") as f:
        for r in tbl: f.write(json.dumps(r,ensure_ascii=False)+"\n")
    ctx={
      "task":t,
      "instruction":INSTR[t],
      "candidates":CAND[t],
      "wp_l1":sorted(WP_L1),
      "wp_splits":[list(x) for x in sorted(WP_SPLITS)],
      "format_spec":FORMAT_SPEC[t],
      "n_records":len(tbl),
    }
    with open(os.path.join(CTX_DIR,t+".json"),"w",encoding="utf-8") as f:
        json.dump(ctx,f,ensure_ascii=False,indent=1)
    print(f"[{t}] table={len(tbl)} candidates={len(CAND[t]) if CAND[t] else 0}")
print("DONE")
