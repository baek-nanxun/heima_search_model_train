#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 1: scan each task, build deduped invalid-label inventory.
Writes _clean/inventory/<task>.json with: total, parse_error_count, candidate_count,
and distinct[] = {key, count, samples, determ_valid, detail}.
"""
import json, re, os, sys

BASE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/code/data/gemini_labeled_v2/tasks_fixed"
JOB_CATE = "/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/job_cate.json"
INV_DIR = os.path.join(BASE, "_clean", "inventory")
os.makedirs(INV_DIR, exist_ok=True)

# ---------- helpers ----------
def tolerant_json(s):
    if not isinstance(s, str):
        return None
    s = s.strip()
    try:
        return json.loads(s)
    except Exception:
        pass
    # strip ```json fences
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", s, re.S)
    if m:
        try:
            return json.loads(m.group(1))
        except Exception:
            pass
    # find first balanced-ish {...}
    m = re.search(r"\{.*\}", s, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return None

def assistant_content(d):
    if d.get("output"):
        return d["output"]
    for m in d.get("messages", []):
        if m.get("role") == "assistant":
            return m.get("content", "")
    return None

def extract_candidates(instr):
    m = re.search(r"候选分类体系（必须严格遵守）：(\[.*?\])", instr, re.S)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None

# ---------- build taxonomy from job_cate.json ----------
with open(JOB_CATE, encoding="utf-8") as f:
    jc = json.load(f)

L3_SET = set()                 # all level3 names
L3_PARENTS = {}                # level3 -> set of (level2, level1)
PATH_SET = set()               # (level1, level2)
CHILDREN_OF = {}               # (level1, level2) -> set(level3)
for l1, l2map in jc.items():
    for l2, l3list in l2map.items():
        PATH_SET.add((l1, l2))
        CHILDREN_OF.setdefault((l1, l2), set())
        for l3 in l3list:
            L3_SET.add(l3)
            L3_PARENTS.setdefault(l3, set()).add((l2, l1))
            CHILDREN_OF[(l1, l2)].add(l3)

# ---------- per-task config ----------
TASKS = {
    "benefit_classification": {"kind": "single", "field": "standardBenefit"},
    "work_time_classification": {"kind": "worktime"},
    "workplace_classification": {"kind": "workplace"},
    "settlement_classification": {"kind": "single", "field": "category"},
    "work_type_classification": {"kind": "single", "field": "category"},
    "taxonomy_leaf_to_parent": {"kind": "leaf"},
    "taxonomy_level2_to_children": {"kind": "children"},
}

def label_of(task, parsed, raw):
    """Return (key_str, entity_str, determ_valid, detail_dict) or (None,...) if unparseable."""
    kind = TASKS[task]["kind"]
    if parsed is None:
        return None, None, False, {"err": "parse_fail"}
    if kind == "single":
        f = TASKS[task]["field"]
        val = parsed.get(f)
        cand = CAND[task]
        valid = isinstance(val, str) and val in cand
        return val if val is not None else "", parsed.get("entity", ""), valid, {"field": f, "val": val}
    if kind == "worktime":
        fc = parsed.get("fullCategory")
        l1, l2 = parsed.get("level1"), parsed.get("level2")
        cand = CAND[task]
        valid = isinstance(fc, str) and fc in cand and (isinstance(l1, str) and isinstance(l2, str) and fc == l1 + "-" + l2)
        return fc if fc is not None else "", parsed.get("entity", ""), valid, {"fc": fc, "l1": l1, "l2": l2}
    if kind == "workplace":
        l1, l2 = parsed.get("level1"), parsed.get("level2")
        rawwp = parsed.get("rawWorkPlace", "")
        valid = isinstance(l1, str) and l1 in WP_L1 and (
            (isinstance(l2, str) and (l1, l2) in WP_SPLITS) or (isinstance(l2, str) and l2 == rawwp)
        )
        key = f"{l1}||{l2}"
        return key, rawwp, valid, {"l1": l1, "l2": l2, "raw": rawwp}
    if kind == "leaf":
        l3, l2, l1 = parsed.get("level3"), parsed.get("level2"), parsed.get("level1")
        valid = isinstance(l3, str) and l3 in L3_PARENTS and (
            isinstance(l2, str) and isinstance(l1, str) and (l2, l1) in L3_PARENTS.get(l3, set())
        )
        key = f"{l3}||{l2}||{l1}"
        return key, l3, valid, {"l3": l3, "l2": l2, "l1": l1}
    if kind == "children":
        l1, l2 = parsed.get("level1"), parsed.get("level2")
        kids = parsed.get("level3Children", []) or []
        kids = [k for k in kids if isinstance(k, str)]
        valid = isinstance(l1, str) and isinstance(l2, str) and (l1, l2) in CHILDREN_OF and set(kids) <= CHILDREN_OF[(l1, l2)]
        key = f"{l1}||{l2}||" + "|".join(sorted(kids))
        return key, f"{l1}/{l2}", valid, {"l1": l1, "l2": l2, "n_kids": len(kids)}
    return None, None, False, {}

# ---------- precompute business candidate sets ----------
CAND = {}
WP_L1 = set()
WP_SPLITS = set()
for t in TASKS:
    p = os.path.join(BASE, t, "train.jsonl")
    with open(p, encoding="utf-8") as f:
        first = json.loads(f.readline())
    instr = first.get("instruction", "")
    if TASKS[t]["kind"] == "workplace":
        c = extract_candidates(instr)
        WP_L1 = set(x.split("-", 1)[0] for x in c)
        WP_SPLITS = set(tuple(x.split("-", 1)) for x in c)
        CAND[t] = c
    elif TASKS[t]["kind"] in ("single", "worktime"):
        CAND[t] = extract_candidates(instr)

# ---------- scan ----------
for t in TASKS:
    p = os.path.join(BASE, t, "train.jsonl")
    total = 0
    parse_err = 0
    distinct = {}  # key -> {count, samples, determ_valid, detail}
    with open(p, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total += 1
            try:
                d = json.loads(line)
            except Exception:
                parse_err += 1
                continue
            content = assistant_content(d)
            parsed = tolerant_json(content)
            key, entity, valid, detail = label_of(t, parsed, content)
            if key is None:
                parse_err += 1
                key = "__PARSE_FAIL__"
                entity = ""
                valid = False
                detail = {"err": "parse_fail"}
            rec = distinct.get(key)
            if rec is None:
                distinct[key] = {"count": 1, "samples": [], "determ_valid": valid, "detail": detail}
                rec = distinct[key]
            else:
                rec["count"] += 1
                rec["determ_valid"] = rec["determ_valid"] and valid
            if len(rec["samples"]) < 3 and entity:
                if entity not in rec["samples"]:
                    rec["samples"].append(entity)
    inv = {
        "task": t,
        "total": total,
        "parse_error_count": parse_err,
        "candidate_count": len(CAND.get(t, [])) if t in CAND else None,
        "distinct": [
            {"key": k, "count": v["count"], "samples": v["samples"],
             "determ_valid": v["determ_valid"], "detail": v["detail"]}
            for k, v in sorted(distinct.items(), key=lambda x: -x[1]["count"])
        ],
    }
    out = os.path.join(INV_DIR, t + ".json")
    with open(out, "w", encoding="utf-8") as f:
        json.dump(inv, f, ensure_ascii=False, indent=1)
    n_invalid = sum(1 for v in distinct.values() if not v["determ_valid"])
    changed_records = sum(v["count"] for v in distinct.values() if not v["determ_valid"])
    print(f"[{t}] total={total} distinct_labels={len(distinct)} "
          f"distinct_invalid(determ)={n_invalid} records_invalid={changed_records} parse_err={parse_err}")
