#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 2 prep: split tables into shards, emit manifest.json for agent dispatch."""
import json, os
BASE="/Users/kingba/Documents/LLM_TEC/图谱建设项目/模型微调/code/data/gemini_labeled_v2/tasks_fixed"
TBL=os.path.join(BASE,"_clean","tables")
SH=os.path.join(BASE,"_clean","shards")
CTX=os.path.join(BASE,"_clean","context")
DEC=os.path.join(BASE,"_clean","decisions")
os.makedirs(SH,exist_ok=True); os.makedirs(DEC,exist_ok=True)

# task -> number of shards
PLAN={
 "benefit_classification":7,
 "work_time_classification":3,
 "workplace_classification":3,
}
manifest=[]
for t,nsh in PLAN.items():
    lines=[l for l in open(os.path.join(TBL,t+".jsonl"),encoding="utf-8")]
    n=len(lines)
    sz=(n+nsh-1)//nsh
    for i in range(nsh):
        chunk=lines[i*sz:(i+1)*sz]
        sp=os.path.join(SH,f"{t}__{i}.jsonl")
        with open(sp,"w",encoding="utf-8") as f:
            f.writelines(chunk)
        manifest.append({"task":t,"shard":sp,"ctx":os.path.join(CTX,t+".json"),
                         "decision":os.path.join(DEC,f"{t}__{i}.jsonl"),"n":len(chunk)})
# small tasks: one shard each, grouped under a 'small' agent
small=["settlement_classification","work_type_classification","taxonomy_leaf_to_parent","taxonomy_level2_to_children"]
small_items=[]
for t in small:
    sp=os.path.join(SH,f"{t}__0.jsonl")
    with open(sp,"w",encoding="utf-8") as f:
        f.writelines(open(os.path.join(TBL,t+".jsonl"),encoding="utf-8"))
    small_items.append({"task":t,"shard":sp,"ctx":os.path.join(CTX,t+".json"),
                        "decision":os.path.join(DEC,f"{t}__0.jsonl")})
manifest.append({"task":"__SMALL__","items":small_items})
with open(os.path.join(BASE,"_clean","shards","manifest.json"),"w",encoding="utf-8") as f:
    json.dump(manifest,f,ensure_ascii=False,indent=1)
print("shards:",sum(len(m.get('items',[m])) for m in manifest if m['task']!='__SMALL__')+ (1 if any(m['task']=='__SMALL__' for m in manifest) else 0))
for m in manifest:
    if m['task']=='__SMALL__':
        print("__SMALL__:", [(it['task'],it['n'] if 'n' in it else '?') for it in m['items']])
    else:
        print(m['task'], m['shard'], "n=",m['n'])
